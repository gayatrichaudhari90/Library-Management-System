from django.shortcuts import render ,redirect
from bookapp.models import Book
from bookapp.forms import AddBookForm , UpdateBookForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm


# def register_user(request)


@login_required
def add(request):
    form = AddBookForm()
    if request.method == 'POST':
        form = AddBookForm(request.POST , request.FILES)
        if form.is_valid():
            form.save()
    return render(request , "bookapp/add.html" , {'form':form})

@login_required
def list(request):
    data = Book.objects.all()
    return render(request , 'bookapp/list.html',{'data':data})

@login_required
def detail(request , id):
    obj = Book.objects.get(pk = id)
    return render(request , "bookapp/detail.html" ,{'obj':obj})

@login_required
def update(request , id):
    obj = Book.objects.get(pk = id)
    form = UpdateBookForm(instance = obj)
    if request.method =="POST":
        form = UpdateBookForm(request.POST ,request.FILES ,instance =obj)
        if form.is_valid():
            form.save()
            return redirect(f"/bookapp/detail/{obj.id}/")
    return render(request ,"bookapp/update.html",{'obj':obj ,'form':form})

@login_required
def delete(request ,id):
    obj = Book.objects.get(pk = id)
    obj.delete()
    return redirect("/bookapp/list/")
