from django.urls import path
from bookapp import views

urlpatterns = [
    path('add/',views.add),
    path('list/',views.list),
    path('detail/<int:id>/',views.detail),
    path('update/<int:id>/',views.update),
    path('delete/<int:id>/',views.delete),

]
