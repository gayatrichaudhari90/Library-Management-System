from django.db import models

# Create your models here.
class Book(models.Model):
    book_name  = models.CharField(max_length=200)
    author_name = models.CharField(max_length=200)
    book_price  = models.FloatField()
    book_img    = models.ImageField(upload_to="images/",null=True,blank=True)

    def __str__(self):
        return self.book_name